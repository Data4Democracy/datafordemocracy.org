---
layout: page
title: "How can I get involved?"
subheadline: "Join Us"
teaser: ""
permalink: "/join_us/"
header:
    image_fullwidth: "header_drop.jpg"
---
Whether you’re an experienced data scientist looking for a side project, still learning, or just trying to figure out how you can help, we’re inviting you to join us. This is an experiment to see how the data science community comes together. Email jonathon [at] datafordemocracy.org for an invitation.


